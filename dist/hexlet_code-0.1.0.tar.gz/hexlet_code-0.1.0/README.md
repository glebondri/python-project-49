### Hexlet tests and linter status:
[![Actions Status](https://github.com/glebondri/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/glebondri/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/33be3e7a915f3a54b2c6/maintainability)](https://codeclimate.com/github/glebondri/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/3B6vUU52kx9dsiKSNcpd6MFlo.svg)](https://asciinema.org/a/3B6vUU52kx9dsiKSNcpd6MFlo)
